package bar;
	
import java.util.Scanner;

	public class ContaBar {
		public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.printf("Informe o sexo (M/F): ");
		char sexo = scanner.next().toUpperCase().charAt(0);
		
		System.out.printf("Quantidade de cervejas: ");
        int qtdCervejas = scanner.nextInt();
        
        System.out.printf("Quantidade de refrigerantes: ");
        int qtdRefrigerantes = scanner.nextInt();

        System.out.printf("Quantidade de espetinhos: ");
        int qtdEspetinhos = scanner.nextInt();
        
        double totalIngresso = 0;
        
        if (sexo == 'M') {
        	totalIngresso = 10;
        }
        else if (sexo == 'F') {
        	totalIngresso = 8;
        }
        
        double totalCervejas = qtdCervejas * 5;
        double totalRefrigerantes = qtdRefrigerantes * 3;
        double totalEspetinhos = qtdEspetinhos * 7;
        double totalConsumo = totalCervejas + totalRefrigerantes + totalEspetinhos;
        double totalConta = totalIngresso + totalConsumo;

        if (totalConsumo <= 30) {
            totalConta += 4; 
        }
        
        System.out.println("\nRelatório da Conta:");
        System.out.printf("Ingresso: R$ %.2f%n", totalIngresso);
        System.out.printf("Consumo: R$ %.2f%n",totalConsumo);
        
        if (totalConsumo > 30) {
            System.out.println("Taxa de Couvert: Isento");
        } else {
            System.out.println("Taxa de Couvert: R$ 4.00");
        }
        
        System.out.printf("Total a Pagar: R$ %.2f%n", totalConta);

        scanner.close();
        
	}

}



