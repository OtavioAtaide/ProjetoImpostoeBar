package imposto;

import java.util.Scanner;

public class ImpostoRenda {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.printf("Renda anual com salário: ");
		double RendaSalarioAnual = scanner.nextDouble();
		
		System.out.printf("Renda anual com prestação de serviço: ");
		double RendaPrestacaoServicoAnual = scanner.nextDouble();
		
		System.out.printf("Renda anual com ganho de capital: ");
		double RendaGanhoCapitalAnual = scanner.nextDouble();
		
		System.out.printf("Gastos médicos: ");
		double GastosMedicos = scanner.nextDouble();
		
		System.out.printf("Gastos educacionais: ");
		double GastosEducacionais = scanner.nextDouble();
		
		double RendaSalarioMensal = RendaSalarioAnual/12;
		double ImpostoSalarioAnual = 0;
		double ImpostoPrestacaoServico = RendaPrestacaoServicoAnual * 0.15;
		double ImpostoGanhoCapital = RendaGanhoCapitalAnual * 0.20;
		
		if (RendaSalarioMensal < 3000) {
			ImpostoSalarioAnual = 0;
		}
		else if (RendaSalarioMensal > 3000 && RendaSalarioMensal < 5000) {
			ImpostoSalarioAnual = RendaSalarioAnual * 0.10;
		}
		else {
			ImpostoSalarioAnual = RendaSalarioAnual * 0.20;
		}
		
		double ImpostoBrutoTotal = ImpostoSalarioAnual + ImpostoPrestacaoServico + ImpostoGanhoCapital;
		double GastosDedutiveis = GastosMedicos + GastosEducacionais;
		double MaximoDedutivel = ImpostoBrutoTotal * 0.30;
		double Abatimento = 0;
		
		if(GastosDedutiveis > MaximoDedutivel) {
			Abatimento = MaximoDedutivel ;
		}else {
			Abatimento = GastosDedutiveis;
		}
		
		double ImpostoDevido = ImpostoBrutoTotal - Abatimento;
		
		System.out.println("\nRELATÓRIO DE IMPOSTO DE RENDA");
		System.out.println("\nCONSOLIDADO DE RENDA");
		System.out.printf("Imposto sobre o salário: %.2f\n",ImpostoSalarioAnual);
		System.out.printf("Imposto sobre prestação de serviços: %.2f\n",ImpostoPrestacaoServico);
		System.out.printf("Imposto sobre ganho de capital: %.2f\n",ImpostoGanhoCapital);
		
		System.out.println("\nDEDUÇÕES");
		System.out.printf("Máximo dedutível: %.2f\n",MaximoDedutivel);
		System.out.printf("Gastos dedutíveis: %.2f\n",GastosDedutiveis);
		
		System.out.println("\nRESUMO");
		System.out.printf("Imposto bruto total: %.2f\n",ImpostoBrutoTotal);
		System.out.printf("Abatimento: %.2f\n",Abatimento);
		System.out.printf("Imposto devido: %.2f\n",ImpostoDevido);
		
		scanner.close();

	}

}
